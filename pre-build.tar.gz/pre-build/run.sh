#!/bin/sh

foot -e bash -c "gdb-multiarch -x gdbscript.py" &
./qemu-system-arm -machine stm32h750 -s -S \
-kernel bootloader.bin -serial stdio -display none \
-device loader,file=kernel.bin,addr=0x90000000
